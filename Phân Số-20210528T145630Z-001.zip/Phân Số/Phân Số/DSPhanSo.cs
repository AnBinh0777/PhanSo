﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Phân_Số
{
    class Ctapphanso
    {
        int soluong;
        Cphanso[] tapps;

        public Ctapphanso()
        {
            soluong = 0;
            tapps = new Cphanso[100];
        }

        public void themphanso(Cphanso x)
        {
            tapps[soluong] = x;
            soluong++;
        }

        public string xuattapphanso()
        {
            string s = "";
            for(int i=0; i < soluong; i++)
            {
                s = s + "  " + tapps[i].xuatphanso();
            }
            return s;
        }
        

        /*public void taongaunhien(int n)
        {
            soluong = n;
            for(int i=0;i<n;i++)
            {
                Cphanso a = new Cphanso();
                a.taongaunhien();
                tapps[i] = a;
                
            }*/
        }

    }

