﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Phân_Số
{
    public class Cphanso
    {
        int tuso;
        int mauso;
        public Cphanso()
        {
            tuso = 1;
            mauso = 2;
        }

        public Cphanso(int a, int b)
        {
            tuso = a;
            mauso = b;
        }

        public Cphanso(string ts, string ms)
        {
            tuso = int.Parse(ts);
            mauso = int.Parse(ms);
            if (mauso == 0)
            {
                mauso = 1;
            }
        }
        public string xuatphanso()
        {
            return tuso + "/" + mauso;
        }

        //public Cphanso cong(Cphanso a)
        public static Cphanso operator +(Cphanso a, Cphanso b)
        {
            Cphanso c = new Cphanso();
            c.tuso = a.mauso * b.tuso + a.tuso * b.mauso;
            c.mauso = a.mauso * b.mauso;
            return c;
        }
      /*  public void taongaunhien()
        {
            Random r = new Random(100);
            Thread.Sleep(100);
            tuso= r.Next(100);
            Thread.Sleep(100);
            mauso= r.Next(100);
        }*/
    }
}
