﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace Phân_Số
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Cphanso a;
        Cphanso b;
        Cphanso c;
        Ctapphanso tps;

        public MainWindow()
        {
            InitializeComponent();
            tps = new Ctapphanso();
        }

        private void Btnxuat_Click_1(object sender, RoutedEventArgs e)
        {
            a = new Cphanso(txttuso.Text, txtmauso.Text);
            Cphanso k = new Cphanso(txttuso.Text, txtmauso.Text);
            tps.themphanso(k);
            //b = new Cphanso(txttuso.Text, txtmauso.Text);

            //txtkq.Text = a.xuatphanso();
            txtkq.Text = tps.xuattapphanso();
            //txtkq.Text = b.xuatphanso();

         /*   Random r = new Random(100);
            Thread.Sleep(100);
            txttuso.Text = r.Next(100).ToString();
            Thread.Sleep(100);
            txtmauso.Text = r.Next(100).ToString
            */

        }

        private void Btntong_Click_1(object sender, RoutedEventArgs e)
        {
            Cphanso b= new Cphanso();
            c = a + b;
            txtkq.Text = c.xuatphanso();
        }

        private void txtkq_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtmauso_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btntru_Click(object sender, RoutedEventArgs e)
        {
            
                Cphanso b = new Cphanso();
                
                txtkq.Text = c.xuatphanso();
            
        }

        private void txttuso_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

